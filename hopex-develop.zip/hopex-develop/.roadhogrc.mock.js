const trade = require('./mock/index')
const user = require('./mock/user')
export default {
  ...trade,
  ...user,
}
