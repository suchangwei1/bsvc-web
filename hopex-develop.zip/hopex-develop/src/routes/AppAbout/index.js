import React, { Component } from 'react'
import { connect } from 'dva'
import * as styles from './index.less'

export default class View extends Component {
  render() {
    return (
      <div className='appabout'>ahhahahah</div >
    )
  }
}
